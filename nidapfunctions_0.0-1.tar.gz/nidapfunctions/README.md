# NIDAP Functions
This package will contain all NIDAP specific functions
